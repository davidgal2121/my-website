import React, { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  variant?: 'default' | 'hover' | 'interactive';
  padding?: 'none' | 'sm' | 'md' | 'lg';
}

const Card: React.FC<CardProps> = ({
  children,
  className = '',
  variant = 'default',
  padding = 'md',
}) => {
  const variantClasses = {
    default: 'shadow-card',
    hover: 'shadow-card hover:shadow-card-hover transition-shadow duration-300',
    interactive: 'shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1',
  }[variant];

  const paddingClasses = {
    none: '',
    sm: 'p-2',
    md: 'p-4',
    lg: 'p-6',
  }[padding];

  return (
    <div className={`bg-white rounded-lg ${variantClasses} ${paddingClasses} ${className}`}>
      {children}
    </div>
  );
};

export default Card;