import React from 'react';

interface Column<T> {
  title: string;
  key: keyof T | ((item: T) => React.ReactNode);
  render?: (value: any, item: T) => React.ReactNode;
}

interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  keyExtractor: (item: T) => string;
  className?: string;
  emptyMessage?: string;
}

function DataTable<T>({
  data,
  columns,
  keyExtractor,
  className = '',
  emptyMessage = 'אין נתונים להצגה'
}: DataTableProps<T>) {
  if (!data.length) {
    return (
      <div className="py-8 text-center text-gray-500">
        {emptyMessage}
      </div>
    );
  }

  return (
    <div className={`overflow-x-auto ${className}`}>
      <table className="min-w-full divide-y divide-gray-200">
        <thead>
          <tr>
            {columns.map((column, index) => (
              <th
                key={index}
                className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                {column.title}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200 bg-white">
          {data.map(item => (
            <tr key={keyExtractor(item)} className="hover:bg-gray-50">
              {columns.map((column, index) => (
                <td key={index} className="px-6 py-4 text-sm text-gray-500">
                  {column.render
                    ? column.render(
                        typeof column.key === 'function'
                          ? column.key(item)
                          : (item[column.key] as any),
                        item
                      )
                    : typeof column.key === 'function'
                    ? column.key(item)
                    : (item[column.key] as any)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default DataTable;