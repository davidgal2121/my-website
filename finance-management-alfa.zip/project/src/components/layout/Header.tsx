import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useNotification } from '../../context/NotificationContext';
import { 
  Menu as MenuIcon, 
  Bell, 
  User, 
  LogOut, 
  Settings, 
  Users, 
  Home, 
  DollarSign, 
  Briefcase, 
  BookOpen, 
  FileText 
} from 'lucide-react';
import Button from '../ui/Button';

const Header: React.FC = () => {
  const { user, logout } = useAuth();
  const { notifications, unreadCount, markAsRead } = useNotification();
  const [menuOpen, setMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'דף הבית', icon: <Home size={18} /> },
    { path: '/finance', label: 'ניהול כספים', icon: <DollarSign size={18} /> },
    { path: '/jobs', label: 'מציאת עבודות', icon: <Briefcase size={18} /> },
    { path: '/guides', label: 'מדריכים', icon: <BookOpen size={18} /> },
    { path: '/blog', label: 'בלוג', icon: <FileText size={18} /> }
  ];

  const handleNotificationClick = (id: string) => {
    markAsRead(id);
    setNotificationsOpen(false);
  };

  const toggleMenu = () => setMenuOpen(!menuOpen);
  const toggleNotifications = () => {
    setNotificationsOpen(!notificationsOpen);
    setUserMenuOpen(false);
  };
  const toggleUserMenu = () => {
    setUserMenuOpen(!userMenuOpen);
    setNotificationsOpen(false);
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo and mobile menu button */}
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <button className="md:hidden p-2 mr-2 rounded-md text-gray-400" onClick={toggleMenu}>
                <MenuIcon className="h-6 w-6" />
              </button>
              <Link to="/" className="font-bold text-xl text-primary-600 flex items-center">
                <DollarSign className="h-6 w-6 mr-1" />
                פיננסי
              </Link>
            </div>
          </div>

          {/* Navigation - hidden on mobile */}
          <nav className="hidden md:flex space-x-8 space-x-reverse">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`inline-flex items-center px-1 pt-1 text-sm font-medium border-b-2 ${
                  location.pathname === item.path
                    ? 'border-primary-500 text-gray-900'
                    : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                }`}
              >
                <span className="ml-1">{item.icon}</span>
                {item.label}
              </Link>
            ))}
          </nav>

          {/* User and notifications */}
          <div className="flex items-center">
            {/* Notifications */}
            <div className="relative ml-3">
              <button
                className="p-1 rounded-full text-gray-400 hover:text-gray-500 focus:outline-none"
                onClick={toggleNotifications}
              >
                <span className="sr-only">התראות</span>
                <Bell className="h-6 w-6" />
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-primary-500 ring-2 ring-white" />
                )}
              </button>
              
              {notificationsOpen && (
                <div className="origin-top-left absolute left-0 mt-2 w-80 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                  <div className="p-4 max-h-96 overflow-auto">
                    <h3 className="text-lg font-medium border-b pb-2">התראות</h3>
                    {notifications.length === 0 ? (
                      <p className="mt-4 text-gray-500 text-center">אין לך התראות חדשות</p>
                    ) : (
                      <div className="mt-2 space-y-2">
                        {notifications.slice(0, 5).map((notification) => (
                          <div 
                            key={notification.id} 
                            className={`p-2 rounded ${notification.read ? 'bg-white' : 'bg-blue-50'}`}
                            onClick={() => handleNotificationClick(notification.id)}
                          >
                            <p className="text-sm font-semibold">{notification.title}</p>
                            <p className="text-xs text-gray-600">{notification.message}</p>
                            <p className="text-xs text-gray-400 mt-1">
                              {new Date(notification.date).toLocaleDateString('he-IL')}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                    <div className="mt-4 text-center">
                      <Link to="/notifications" className="text-primary-600 text-sm hover:underline">
                        הצג את כל ההתראות
                      </Link>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* User menu */}
            <div className="relative ml-3">
              <button
                className="flex text-sm rounded-full focus:outline-none"
                onClick={toggleUserMenu}
              >
                <span className="sr-only">פתח תפריט משתמש</span>
                <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
                  {user?.avatar ? (
                    <img src={user.avatar} alt={user.name} className="h-full w-full object-cover" />
                  ) : (
                    <User size={20} className="text-gray-500" />
                  )}
                </div>
              </button>

              {userMenuOpen && (
                <div className="origin-top-left absolute left-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none">
                  <div className="py-1">
                    {user ? (
                      <>
                        <div className="px-4 py-2 text-xs text-gray-400">
                          מחובר כ- <span className="font-semibold text-gray-700">{user.name}</span>
                        </div>
                        <Link
                          to="/profile"
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                          onClick={() => setUserMenuOpen(false)}
                        >
                          <User size={16} className="ml-2" />
                          הפרופיל שלי
                        </Link>
                        <Link
                          to="/settings"
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                          onClick={() => setUserMenuOpen(false)}
                        >
                          <Settings size={16} className="ml-2" />
                          הגדרות
                        </Link>
                        <Link
                          to="/share"
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                          onClick={() => setUserMenuOpen(false)}
                        >
                          <Users size={16} className="ml-2" />
                          שיתוף עם הורה/אפוטרופוס
                        </Link>
                        <button
                          className="block w-full text-right px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                          onClick={() => {
                            setUserMenuOpen(false);
                            logout();
                          }}
                        >
                          <LogOut size={16} className="ml-2" />
                          יציאה
                        </button>
                      </>
                    ) : (
                      <div className="px-4 py-2">
                        <Button
                          variant="primary"
                          fullWidth
                          onClick={() => setUserMenuOpen(false)}
                        >
                          התחבר
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden">
          <div className="pt-2 pb-3 space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`block pl-3 pr-4 py-2 border-r-4 text-base font-medium ${
                  location.pathname === item.path
                    ? 'border-primary-500 text-primary-700 bg-primary-50'
                    : 'border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300'
                } flex items-center`}
                onClick={() => setMenuOpen(false)}
              >
                <span className="ml-2">{item.icon}</span>
                {item.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;