import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Linkedin, Info, FileText, Shield, HelpCircle } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-200 py-8 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between">
          <div className="mb-6 md:mb-0">
            <Link to="/" className="flex items-center font-bold text-xl text-primary-600">
              פיננסי
            </Link>
            <p className="mt-2 text-sm text-gray-500 max-w-xs">
              הפלטפורמה המובילה לניהול פיננסי ומציאת עבודות לבני נוער בישראל
            </p>
          </div>

          <div className="grid grid-cols-2 gap-8 md:gap-16">
            <div>
              <h3 className="text-sm font-semibold text-gray-600 tracking-wider uppercase">קישורים</h3>
              <ul className="mt-4 space-y-2">
                <li>
                  <Link to="/about" className="text-gray-500 hover:text-gray-900 flex items-center">
                    <Info size={16} className="ml-1" />
                    אודות
                  </Link>
                </li>
                <li>
                  <Link to="/terms" className="text-gray-500 hover:text-gray-900 flex items-center">
                    <FileText size={16} className="ml-1" />
                    תנאי שימוש
                  </Link>
                </li>
                <li>
                  <Link to="/privacy" className="text-gray-500 hover:text-gray-900 flex items-center">
                    <Shield size={16} className="ml-1" />
                    מדיניות פרטיות
                  </Link>
                </li>
                <li>
                  <Link to="/help" className="text-gray-500 hover:text-gray-900 flex items-center">
                    <HelpCircle size={16} className="ml-1" />
                    מרכז עזרה
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-600 tracking-wider uppercase">עקבו אחרינו</h3>
              <div className="mt-4 flex space-x-6 space-x-reverse">
                <a href="#" className="text-gray-400 hover:text-primary-500">
                  <span className="sr-only">Facebook</span>
                  <Facebook size={20} />
                </a>
                <a href="#" className="text-gray-400 hover:text-primary-500">
                  <span className="sr-only">Instagram</span>
                  <Instagram size={20} />
                </a>
                <a href="#" className="text-gray-400 hover:text-primary-500">
                  <span className="sr-only">LinkedIn</span>
                  <Linkedin size={20} />
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-gray-200 pt-4 flex flex-col sm:flex-row justify-between">
          <p className="text-sm text-gray-500">
            &copy; {new Date().getFullYear()} פיננסי. כל הזכויות שמורות.
          </p>
          <p className="text-sm text-gray-400 mt-2 sm:mt-0">
            גרסת המערכת: v1.0
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;