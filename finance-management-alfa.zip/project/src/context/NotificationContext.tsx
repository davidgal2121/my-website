import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Notification } from '../types';

// Mock data
const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'income',
    title: 'תשלום התקבל',
    message: 'קיבלת 200 ₪ מ"בייביסיטר"',
    date: new Date().toISOString(),
    read: false,
  },
  {
    id: '2',
    type: 'job',
    title: 'משרה חדשה התפרסמה',
    message: 'משרת "מלצר/ית לאירועים" התפרסמה באזורך',
    date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // yesterday
    read: true,
  },
  {
    id: '3',
    type: 'goal',
    title: 'יעד קרוב להשגה',
    message: 'נותרו 300 ₪ להשגת היעד "טלפון חדש"',
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
    read: false,
  },
];

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Omit<Notification, 'id' | 'date' | 'read'>) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  deleteNotification: (id: string) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);

  const unreadCount = notifications.filter(n => !n.read).length;

  const addNotification = (notification: Omit<Notification, 'id' | 'date' | 'read'>) => {
    const newNotification: Notification = {
      ...notification,
      id: Date.now().toString(),
      date: new Date().toISOString(),
      read: false,
    };
    setNotifications([newNotification, ...notifications]);
  };

  const markAsRead = (id: string) => {
    setNotifications(
      notifications.map(notification =>
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(
      notifications.map(notification => ({ ...notification, read: true }))
    );
  };

  const deleteNotification = (id: string) => {
    setNotifications(notifications.filter(notification => notification.id !== id));
  };

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        addNotification,
        markAsRead,
        markAllAsRead,
        deleteNotification,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotification = (): NotificationContextType => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotification must be used within a NotificationProvider');
  }
  return context;
};