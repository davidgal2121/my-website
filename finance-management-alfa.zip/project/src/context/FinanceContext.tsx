import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Income, Expense, FinancialGoal, FinancialReport } from '../types';

// Generate mockup data
const currentDate = new Date().toISOString().split('T')[0];
const lastMonth = new Date();
lastMonth.setMonth(lastMonth.getMonth() - 1);
const lastMonthString = lastMonth.toISOString().split('T')[0];

// Mock data
const mockIncomes: Income[] = [
  { id: '1', date: currentDate, source: 'בייביסיטר', amount: 200, type: 'temporary', status: 'paid', tags: ['עבודה', 'קיץ'] },
  { id: '2', date: lastMonthString, source: 'מלצרות', amount: 350, type: 'permanent', status: 'paid', tags: ['מסעדה'] },
  { id: '3', date: lastMonthString, source: 'שמרטפות', amount: 150, type: 'temporary', status: 'pending', tags: ['שמרטפות'] },
];

const mockExpenses: Expense[] = [
  { id: '1', date: currentDate, category: 'בידור', amount: 100, status: 'paid', tags: ['סרט', 'חברים'] },
  { id: '2', date: lastMonthString, category: 'אוכל', amount: 75, status: 'paid', tags: ['ארוחת צהריים'] },
  { id: '3', date: lastMonthString, category: 'חיסכון', amount: 200, status: 'paid', tags: ['יעד'] },
];

const mockGoals: FinancialGoal[] = [
  { 
    id: '1', 
    name: 'טלפון חדש', 
    targetAmount: 3000, 
    currentAmount: 1200, 
    targetDate: '2025-08-30',
    icon: 'smartphone'
  },
  { 
    id: '2', 
    name: 'חופשה עם חברים', 
    targetAmount: 2000, 
    currentAmount: 500, 
    targetDate: '2025-07-15',
    icon: 'palmtree'
  },
];

const mockReport: FinancialReport = {
  period: '2025-05',
  incomes: mockIncomes,
  expenses: mockExpenses,
  summary: {
    totalIncome: 700,
    totalExpense: 375,
    balance: 325,
  },
};

interface FinanceContextType {
  incomes: Income[];
  expenses: Expense[];
  goals: FinancialGoal[];
  reports: FinancialReport[];
  currentReport: FinancialReport;
  addIncome: (income: Omit<Income, 'id'>) => void;
  addExpense: (expense: Omit<Expense, 'id'>) => void;
  updateIncome: (id: string, income: Partial<Income>) => void;
  updateExpense: (id: string, expense: Partial<Expense>) => void;
  deleteIncome: (id: string) => void;
  deleteExpense: (id: string) => void;
  addGoal: (goal: Omit<FinancialGoal, 'id'>) => void;
  updateGoal: (id: string, goal: Partial<FinancialGoal>) => void;
  deleteGoal: (id: string) => void;
}

const FinanceContext = createContext<FinanceContextType | undefined>(undefined);

export const FinanceProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [incomes, setIncomes] = useState<Income[]>(mockIncomes);
  const [expenses, setExpenses] = useState<Expense[]>(mockExpenses);
  const [goals, setGoals] = useState<FinancialGoal[]>(mockGoals);
  const [reports] = useState<FinancialReport[]>([mockReport]);
  const [currentReport] = useState<FinancialReport>(mockReport);

  const addIncome = (income: Omit<Income, 'id'>) => {
    const newIncome = { ...income, id: Date.now().toString() };
    setIncomes([newIncome, ...incomes]);
  };

  const addExpense = (expense: Omit<Expense, 'id'>) => {
    const newExpense = { ...expense, id: Date.now().toString() };
    setExpenses([newExpense, ...expenses]);
  };

  const updateIncome = (id: string, income: Partial<Income>) => {
    setIncomes(incomes.map(inc => (inc.id === id ? { ...inc, ...income } : inc)));
  };

  const updateExpense = (id: string, expense: Partial<Expense>) => {
    setExpenses(expenses.map(exp => (exp.id === id ? { ...exp, ...expense } : exp)));
  };

  const deleteIncome = (id: string) => {
    setIncomes(incomes.filter(income => income.id !== id));
  };

  const deleteExpense = (id: string) => {
    setExpenses(expenses.filter(expense => expense.id !== id));
  };

  const addGoal = (goal: Omit<FinancialGoal, 'id'>) => {
    const newGoal = { ...goal, id: Date.now().toString() };
    setGoals([...goals, newGoal]);
  };

  const updateGoal = (id: string, goal: Partial<FinancialGoal>) => {
    setGoals(goals.map(g => (g.id === id ? { ...g, ...goal } : g)));
  };

  const deleteGoal = (id: string) => {
    setGoals(goals.filter(goal => goal.id !== id));
  };

  return (
    <FinanceContext.Provider
      value={{
        incomes,
        expenses,
        goals,
        reports,
        currentReport,
        addIncome,
        addExpense,
        updateIncome,
        updateExpense,
        deleteIncome,
        deleteExpense,
        addGoal,
        updateGoal,
        deleteGoal,
      }}
    >
      {children}
    </FinanceContext.Provider>
  );
};

export const useFinance = (): FinanceContextType => {
  const context = useContext(FinanceContext);
  if (context === undefined) {
    throw new Error('useFinance must be used within a FinanceProvider');
  }
  return context;
};