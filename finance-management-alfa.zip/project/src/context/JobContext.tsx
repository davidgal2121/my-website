import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Job, SavedJob, JobApplication, Resume } from '../types';

// Mock data
const mockJobs: Job[] = [
  {
    id: '1',
    title: 'בייביסיטר',
    company: 'משפחת כהן',
    type: 'temporary',
    salary: {
      amount: 50,
      period: 'hour',
    },
    location: 'תל אביב',
    remote: false,
    description: 'שמרטפות על 2 ילדים בגילאי 4-7, פעמיים בשבוע אחה"צ.',
    requirements: ['ניסיון קודם', 'סבלנות', 'אחריות'],
    postedDate: '2025-05-01',
  },
  {
    id: '2',
    title: 'עוזר/ת מכירות',
    company: 'חנות בגדים "סטייל"',
    type: 'permanent',
    salary: {
      amount: 35,
      period: 'hour',
    },
    location: 'ירושלים',
    remote: false,
    description: 'עבודה בחנות בגדים, סידור סחורה ועזרה ללקוחות.',
    postedDate: '2025-05-03',
  },
  {
    id: '3',
    title: 'עוזר/ת תכנות',
    company: 'טק סטארט',
    type: 'project',
    salary: {
      amount: 2000,
      period: 'project',
    },
    location: 'חיפה',
    remote: true,
    description: 'עזרה בפיתוח אתר אינטרנט בסיסי.',
    requirements: ['ידע בסיסי ב-HTML ו-CSS', 'יכולת למידה עצמית'],
    postedDate: '2025-05-10',
  },
];

const mockSavedJobs: SavedJob[] = [
  {
    job: mockJobs[0],
    dateAdded: '2025-05-10',
    notes: 'מתאים לימי שלישי וחמישי בערב',
  },
];

const mockApplications: JobApplication[] = [
  {
    job: mockJobs[2],
    status: 'applied',
    applicationDate: '2025-05-11',
    notes: 'שלחתי קורות חיים ומכתב פנייה',
  },
];

const mockResume: Resume = {
  personalInfo: {
    name: 'דניאל לוי',
    email: 'daniel@example.com',
    phone: '050-1234567',
  },
  education: [
    {
      institution: 'תיכון אחד העם',
      degree: 'תעודת בגרות',
      fieldOfStudy: 'מגמת מחשבים',
      startDate: '2022-09-01',
      current: true,
    },
  ],
  experience: [
    {
      company: 'פיצה האט',
      position: 'שליח',
      description: 'משלוחי פיצה באזור המרכז',
      startDate: '2024-06-01',
      endDate: '2024-09-01',
    },
  ],
  skills: ['אחריות', 'עבודת צוות', 'סדר וארגון', 'שירות לקוחות'],
};

interface JobContextType {
  allJobs: Job[];
  searchResults: Job[];
  savedJobs: SavedJob[];
  applications: JobApplication[];
  resume: Resume;
  searchJobs: (query: string, filters?: any) => void;
  saveJob: (job: Job, notes?: string) => void;
  removeSavedJob: (jobId: string) => void;
  applyForJob: (job: Job, notes?: string) => void;
  updateApplication: (jobId: string, updates: Partial<JobApplication>) => void;
  updateResume: (resume: Partial<Resume>) => void;
}

const JobContext = createContext<JobContextType | undefined>(undefined);

export const JobProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [allJobs] = useState<Job[]>(mockJobs);
  const [searchResults, setSearchResults] = useState<Job[]>(mockJobs);
  const [savedJobs, setSavedJobs] = useState<SavedJob[]>(mockSavedJobs);
  const [applications, setApplications] = useState<JobApplication[]>(mockApplications);
  const [resume, setResume] = useState<Resume>(mockResume);

  const searchJobs = (query: string, filters?: any) => {
    // Simple search implementation
    if (!query && !filters) {
      setSearchResults(allJobs);
      return;
    }

    const results = allJobs.filter(job => {
      const matchesQuery = !query || 
        job.title.includes(query) || 
        job.company.includes(query) || 
        job.description.includes(query);
      
      // Apply filters if provided
      let matchesFilters = true;
      if (filters) {
        if (filters.type && filters.type.length > 0) {
          matchesFilters = matchesFilters && filters.type.includes(job.type);
        }
        if (filters.remote !== undefined) {
          matchesFilters = matchesFilters && job.remote === filters.remote;
        }
        // Add more filter conditions as needed
      }
      
      return matchesQuery && matchesFilters;
    });
    
    setSearchResults(results);
  };

  const saveJob = (job: Job, notes?: string) => {
    const newSavedJob: SavedJob = {
      job,
      dateAdded: new Date().toISOString().split('T')[0],
      notes,
    };
    setSavedJobs([...savedJobs, newSavedJob]);
  };

  const removeSavedJob = (jobId: string) => {
    setSavedJobs(savedJobs.filter(saved => saved.job.id !== jobId));
  };

  const applyForJob = (job: Job, notes?: string) => {
    const newApplication: JobApplication = {
      job,
      status: 'applied',
      applicationDate: new Date().toISOString().split('T')[0],
      notes,
    };
    setApplications([...applications, newApplication]);
  };

  const updateApplication = (jobId: string, updates: Partial<JobApplication>) => {
    setApplications(applications.map(app => 
      app.job.id === jobId ? { ...app, ...updates } : app
    ));
  };

  const updateResume = (updates: Partial<Resume>) => {
    setResume({ ...resume, ...updates });
  };

  return (
    <JobContext.Provider
      value={{
        allJobs,
        searchResults,
        savedJobs,
        applications,
        resume,
        searchJobs,
        saveJob,
        removeSavedJob,
        applyForJob,
        updateApplication,
        updateResume,
      }}
    >
      {children}
    </JobContext.Provider>
  );
};

export const useJob = (): JobContextType => {
  const context = useContext(JobContext);
  if (context === undefined) {
    throw new Error('useJob must be used within a JobProvider');
  }
  return context;
};