// User Related Types
export interface User {
  id: string;
  name: string;
  email: string;
  age?: number;
  avatar?: string;
  preferredWorkType?: string[];
  bankAccount?: string;
  paypal?: string;
  parentEmail?: string;
  sharingSettings?: {
    income: boolean;
    expenses: boolean;
    reports: boolean;
  };
}

// Financial Related Types
export interface Income {
  id: string;
  date: string;
  source: string;
  amount: number;
  type: 'permanent' | 'temporary' | 'project';
  tags?: string[];
  status: 'pending' | 'paid';
  reminderDate?: string;
}

export interface Expense {
  id: string;
  date: string;
  category: string;
  amount: number;
  tags?: string[];
  status: 'pending' | 'paid';
}

export interface FinancialGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  icon?: string;
}

export interface FinancialReport {
  period: string;
  incomes: Income[];
  expenses: Expense[];
  summary: {
    totalIncome: number;
    totalExpense: number;
    balance: number;
  };
}

// Job Related Types
export interface Job {
  id: string;
  title: string;
  company: string;
  type: 'permanent' | 'temporary' | 'project';
  salary: {
    amount: number;
    period?: 'hour' | 'day' | 'week' | 'month' | 'project';
  };
  location: string;
  remote: boolean;
  description: string;
  requirements?: string[];
  postedDate: string;
  applicationDeadline?: string;
}

export interface SavedJob {
  job: Job;
  dateAdded: string;
  notes?: string;
}

export interface JobApplication {
  job: Job;
  status: 'applied' | 'interview' | 'offer' | 'rejected' | 'withdrawn';
  applicationDate: string;
  notes?: string;
  interviews?: {
    date: string;
    type: string;
    notes?: string;
  }[];
}

export interface Resume {
  personalInfo: {
    name: string;
    email: string;
    phone?: string;
    address?: string;
  };
  education: {
    institution: string;
    degree: string;
    fieldOfStudy?: string;
    startDate: string;
    endDate?: string;
    current?: boolean;
  }[];
  experience: {
    company: string;
    position: string;
    description?: string;
    startDate: string;
    endDate?: string;
    current?: boolean;
  }[];
  skills: string[];
}

// Guide Related Types
export interface Guide {
  id: string;
  title: string;
  category: string;
  summary: string;
  content: string;
  author?: string;
  publishDate: string;
  readTime: number;
  completed?: boolean;
}

// Notification Related Types
export interface Notification {
  id: string;
  type: 'income' | 'expense' | 'goal' | 'job' | 'system';
  title: string;
  message: string;
  date: string;
  read: boolean;
  actionUrl?: string;
}

// Task Related Types
export interface Task {
  id: string;
  title: string;
  dueDate?: string;
  completed: boolean;
  category?: 'financial' | 'job' | 'personal';
  priority?: 'low' | 'medium' | 'high';
}