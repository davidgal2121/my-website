import React, { useState } from 'react';
import { useFinance } from '../../context/FinanceContext';
import Card from '../../components/ui/Card';
import DataTable from '../../components/ui/DataTable';
import Button from '../../components/ui/Button';
import { Plus, Edit2, Trash2, CheckCircle, Filter } from 'lucide-react';
import { Income } from '../../types';

interface IncomeFormData {
  source: string;
  amount: string;
  type: 'permanent' | 'temporary' | 'project';
  tags: string;
  reminderDate?: string;
}

const IncomeManagement: React.FC = () => {
  const { incomes, addIncome, updateIncome, deleteIncome } = useFinance();
  const [isAddingIncome, setIsAddingIncome] = useState(false);
  const [editingIncomeId, setEditingIncomeId] = useState<string | null>(null);
  const [formData, setFormData] = useState<IncomeFormData>({
    source: '',
    amount: '',
    type: 'temporary',
    tags: '',
  });
  
  // Filter state
  const [filters, setFilters] = useState({
    type: [] as Array<'permanent' | 'temporary' | 'project'>,
    startDate: '',
    endDate: '',
    minAmount: '',
    maxAmount: '',
  });
  const [showFilters, setShowFilters] = useState(false);

  const resetForm = () => {
    setFormData({
      source: '',
      amount: '',
      type: 'temporary',
      tags: '',
    });
    setIsAddingIncome(false);
    setEditingIncomeId(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const incomeData: Omit<Income, 'id'> = {
      date: new Date().toISOString().split('T')[0],
      source: formData.source,
      amount: parseFloat(formData.amount),
      type: formData.type,
      tags: formData.tags ? formData.tags.split(',').map(tag => tag.trim()) : undefined,
      status: 'paid',
      reminderDate: formData.reminderDate,
    };

    if (editingIncomeId) {
      updateIncome(editingIncomeId, incomeData);
    } else {
      addIncome(incomeData);
    }

    resetForm();
  };

  const handleEdit = (income: Income) => {
    setFormData({
      source: income.source,
      amount: income.amount.toString(),
      type: income.type,
      tags: income.tags ? income.tags.join(', ') : '',
      reminderDate: income.reminderDate,
    });
    setEditingIncomeId(income.id);
    setIsAddingIncome(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('האם אתה בטוח שברצונך למחוק הכנסה זו?')) {
      deleteIncome(id);
    }
  };

  const handleMarkAsPaid = (id: string) => {
    updateIncome(id, { status: 'paid' });
  };

  // Apply filters to incomes
  const filteredIncomes = incomes.filter(income => {
    if (filters.type.length && !filters.type.includes(income.type)) return false;
    
    if (filters.minAmount && income.amount < parseFloat(filters.minAmount)) return false;
    if (filters.maxAmount && income.amount > parseFloat(filters.maxAmount)) return false;
    
    if (filters.startDate && income.date < filters.startDate) return false;
    if (filters.endDate && income.date > filters.endDate) return false;
    
    return true;
  });

  const columns = [
    { 
      title: 'תאריך', 
      key: 'date', 
      render: (date: string) => new Date(date).toLocaleDateString('he-IL') 
    },
    { title: 'מקור', key: 'source' },
    { 
      title: 'סכום',
      key: 'amount',
      render: (amount: number) => `${amount} ₪` 
    },
    { 
      title: 'סוג',
      key: 'type',
      render: (type: string) => {
        const typeMap = {
          permanent: 'קבוע',
          temporary: 'זמני',
          project: 'פרויקט',
        } as const;
        
        return typeMap[type as keyof typeof typeMap] || type;
      } 
    },
    { 
      title: 'סטטוס', 
      key: 'status',
      render: (status: string, item: Income) => (
        <span 
          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
            status === 'paid' 
              ? 'bg-success-100 text-success-800' 
              : 'bg-warning-100 text-warning-800'
          }`}
        >
          {status === 'paid' ? 'שולם' : 'ממתין'}
        </span>
      ) 
    },
    {
      title: 'פעולות',
      key: (item: Income) => (
        <div className="flex space-x-2 space-x-reverse">
          {item.status === 'pending' && (
            <Button
              variant="ghost"
              size="sm"
              icon={<CheckCircle size={16} />}
              onClick={() => handleMarkAsPaid(item.id)}
            >
              סמן כשולם
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            icon={<Edit2 size={16} />}
            onClick={() => handleEdit(item)}
          >
            ערוך
          </Button>
          <Button
            variant="ghost"
            size="sm"
            icon={<Trash2 size={16} />}
            onClick={() => handleDelete(item.id)}
          >
            מחק
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">ניהול הכנסות</h2>
        <div className="flex space-x-2 space-x-reverse">
          <Button
            variant="outline"
            icon={<Filter size={16} />}
            onClick={() => setShowFilters(!showFilters)}
          >
            סינון
          </Button>
          <Button 
            variant="primary" 
            icon={<Plus size={16} />}
            onClick={() => setIsAddingIncome(true)}
          >
            הוסף הכנסה
          </Button>
        </div>
      </div>

      {/* Filters Panel */}
      {showFilters && (
        <Card className="mb-4">
          <h3 className="text-lg font-medium mb-3">סינון הכנסות</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">סוג עבודה</label>
              <div className="flex space-x-4 space-x-reverse">
                <label className="inline-flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.type.includes('permanent')}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setFilters(prev => ({
                          ...prev,
                          type: [...prev.type, 'permanent']
                        }));
                      } else {
                        setFilters(prev => ({
                          ...prev,
                          type: prev.type.filter(t => t !== 'permanent')
                        }));
                      }
                    }}
                    className="form-checkbox h-4 w-4 text-primary-600"
                  />
                  <span className="mr-2 text-sm text-gray-700">קבוע</span>
                </label>
                <label className="inline-flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.type.includes('temporary')}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setFilters(prev => ({
                          ...prev,
                          type: [...prev.type, 'temporary']
                        }));
                      } else {
                        setFilters(prev => ({
                          ...prev,
                          type: prev.type.filter(t => t !== 'temporary')
                        }));
                      }
                    }}
                    className="form-checkbox h-4 w-4 text-primary-600"
                  />
                  <span className="mr-2 text-sm text-gray-700">זמני</span>
                </label>
                <label className="inline-flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.type.includes('project')}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setFilters(prev => ({
                          ...prev,
                          type: [...prev.type, 'project']
                        }));
                      } else {
                        setFilters(prev => ({
                          ...prev,
                          type: prev.type.filter(t => t !== 'project')
                        }));
                      }
                    }}
                    className="form-checkbox h-4 w-4 text-primary-600"
                  />
                  <span className="mr-2 text-sm text-gray-700">פרויקט</span>
                </label>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">טווח תאריכים</label>
              <div className="flex space-x-2 space-x-reverse">
                <div>
                  <label className="text-xs text-gray-500">מתאריך</label>
                  <input
                    type="date"
                    value={filters.startDate}
                    onChange={(e) => setFilters(prev => ({ ...prev, startDate: e.target.value }))}
                    className="block w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500">עד תאריך</label>
                  <input
                    type="date"
                    value={filters.endDate}
                    onChange={(e) => setFilters(prev => ({ ...prev, endDate: e.target.value }))}
                    className="block w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 text-sm"
                  />
                </div>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">טווח סכומים (₪)</label>
              <div className="flex space-x-2 space-x-reverse">
                <div>
                  <label className="text-xs text-gray-500">מינימום</label>
                  <input
                    type="number"
                    value={filters.minAmount}
                    onChange={(e) => setFilters(prev => ({ ...prev, minAmount: e.target.value }))}
                    className="block w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 text-sm"
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500">מקסימום</label>
                  <input
                    type="number"
                    value={filters.maxAmount}
                    onChange={(e) => setFilters(prev => ({ ...prev, maxAmount: e.target.value }))}
                    className="block w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 text-sm"
                    placeholder="∞"
                  />
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-4 flex justify-end space-x-2 space-x-reverse">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setFilters({
                  type: [],
                  startDate: '',
                  endDate: '',
                  minAmount: '',
                  maxAmount: '',
                });
              }}
            >
              נקה מסננים
            </Button>
          </div>
        </Card>
      )}

      {/* Add/Edit Income Form */}
      {isAddingIncome && (
        <Card className="mb-4 animate-slide-up">
          <h3 className="text-lg font-medium mb-4">
            {editingIncomeId ? 'עריכת הכנסה' : 'הוספת הכנסה חדשה'}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="source" className="block text-sm font-medium text-gray-700">
                  מקור הכנסה *
                </label>
                <input
                  id="source"
                  type="text"
                  required
                  value={formData.source}
                  onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                />
              </div>
              <div>
                <label htmlFor="amount" className="block text-sm font-medium text-gray-700">
                  סכום (₪) *
                </label>
                <input
                  id="amount"
                  type="number"
                  min="0"
                  step="0.01"
                  required
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="type" className="block text-sm font-medium text-gray-700">
                  סוג עבודה *
                </label>
                <select
                  id="type"
                  required
                  value={formData.type}
                  onChange={(e) => 
                    setFormData({ 
                      ...formData, 
                      type: e.target.value as 'permanent' | 'temporary' | 'project'
                    })
                  }
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="temporary">זמני</option>
                  <option value="permanent">קבוע</option>
                  <option value="project">פרויקט</option>
                </select>
              </div>
              <div>
                <label htmlFor="tags" className="block text-sm font-medium text-gray-700">
                  תוויות (מופרדות בפסיקים)
                </label>
                <input
                  id="tags"
                  type="text"
                  value={formData.tags}
                  onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
                  className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                  placeholder="לדוגמה: קיץ, שמרטפות, מסעדה"
                />
              </div>
            </div>

            <div>
              <label htmlFor="reminderDate" className="block text-sm font-medium text-gray-700">
                תזכורת (אופציונלי)
              </label>
              <input
                id="reminderDate"
                type="date"
                value={formData.reminderDate}
                onChange={(e) => setFormData({ ...formData, reminderDate: e.target.value })}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
              />
            </div>

            <div className="flex justify-end space-x-3 space-x-reverse">
              <Button
                type="button"
                variant="outline"
                onClick={resetForm}
              >
                ביטול
              </Button>
              <Button
                type="submit"
                variant="primary"
              >
                {editingIncomeId ? 'עדכן' : 'הוסף'}
              </Button>
            </div>
          </form>
        </Card>
      )}

      {/* Incomes Table */}
      <Card>
        <DataTable
          data={filteredIncomes}
          columns={columns}
          keyExtractor={(income) => income.id}
          emptyMessage="לא נמצאו הכנסות. הוסף הכנסה חדשה כדי להתחיל."
        />
      </Card>
    </div>
  );
};

export default IncomeManagement;