import React, { useState } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { 
  DollarSign, 
  PieChart, 
  TrendingUp,
  Target,
  Receipt,
  ListChecks
} from 'lucide-react';

const FinanceIndex: React.FC = () => {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState(() => {
    const path = location.pathname;
    if (path.includes('income')) return 'income';
    if (path.includes('expenses')) return 'expenses';
    if (path.includes('goals')) return 'goals';
    if (path.includes('reports')) return 'reports';
    return 'overview';
  });

  const tabs = [
    { id: 'overview', label: 'סקירה כללית', icon: <PieChart size={18} />, path: '/finance' },
    { id: 'income', label: 'הכנסות', icon: <TrendingUp size={18} />, path: '/finance/income' },
    { id: 'expenses', label: 'הוצאות', icon: <Receipt size={18} />, path: '/finance/expenses' },
    { id: 'goals', label: 'יעדים וחיסכון', icon: <Target size={18} />, path: '/finance/goals' },
    { id: 'reports', label: 'דוחות', icon: <ListChecks size={18} />, path: '/finance/reports' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="pb-2">
        <h1 className="text-2xl md:text-3xl font-bold text-gray-800 flex items-center">
          <DollarSign className="mr-2 h-8 w-8 text-primary-500" />
          ניהול כספים
        </h1>
        <p className="text-gray-600 mt-1">
          שליטה בהכנסות והוצאות, הגדרת יעדים וצפייה בדוחות מפורטים
        </p>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8 space-x-reverse overflow-x-auto">
          {tabs.map((tab) => (
            <Link
              key={tab.id}
              to={tab.path}
              className={`
                whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center
                ${activeTab === tab.id
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
              `}
              onClick={() => setActiveTab(tab.id)}
            >
              <span className="ml-2">{tab.icon}</span>
              {tab.label}
            </Link>
          ))}
        </nav>
      </div>

      {/* Content Area */}
      <div className="py-4">
        <Outlet />
      </div>
    </div>
  );
};

export default FinanceIndex;