import React from 'react';
import { useAuth } from '../context/AuthContext';
import FinancialSummary from '../components/dashboard/FinancialSummary';
import GoalsProgress from '../components/dashboard/GoalsProgress';
import QuickActions from '../components/dashboard/QuickActions';
import UpcomingTasks from '../components/dashboard/UpcomingTasks';
import PersonalizedTips from '../components/dashboard/PersonalizedTips';
import MiniCalendar from '../components/dashboard/MiniCalendar';

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="pb-2">
        <h1 className="text-2xl md:text-3xl font-bold text-gray-800">
          מה נשמע, {user?.name?.split(' ')[0] || 'אורח'}?
        </h1>
        <p className="text-gray-600 mt-1">
          ברוכים הבאים למערכת ניהול הכספים והקריירה שלך. הנה מה שקורה אצלך היום.
        </p>
      </div>

      {/* Quick Actions */}
      <section>
        <QuickActions />
      </section>

      {/* Financial Summary */}
      <section className="mt-6">
        <FinancialSummary />
      </section>

      {/* Three Column Layout for Smaller Components */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
        <div className="lg:col-span-1">
          <GoalsProgress />
        </div>
        
        <div className="lg:col-span-1">
          <UpcomingTasks />
        </div>

        <div className="lg:col-span-1">
          <div className="space-y-6">
            <MiniCalendar />
            <PersonalizedTips />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;