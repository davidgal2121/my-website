import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Search, Filter, ArrowRight, Clock, User, Tag } from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';

interface Guide {
  id: string;
  title: string;
  category: string;
  summary: string;
  readTime: number;
  author: string;
  tags: string[];
  image: string;
}

const guides: Guide[] = [
  {
    id: '1',
    title: 'איך לנהל תקציב בגיל צעיר',
    category: 'ניהול כספים',
    summary: 'מדריך מקיף לניהול תקציב חכם, חיסכון והתנהלות פיננסית נבונה לבני נוער.',
    readTime: 8,
    author: 'רונית כהן',
    tags: ['תקציב', 'חיסכון', 'כסף'],
    image: 'https://images.pexels.com/photos/4386431/pexels-photo-4386431.jpeg'
  },
  {
    id: '2',
    title: 'טיפים לראיון עבודה ראשון',
    category: 'קריירה',
    summary: 'כל מה שצריך לדעת לקראת ראיון העבודה הראשון: איך להתכונן, מה ללבוש ואיך להרשים.',
    readTime: 12,
    author: 'דן לוי',
    tags: ['ראיון עבודה', 'קריירה', 'טיפים'],
    image: 'https://images.pexels.com/photos/5668858/pexels-photo-5668858.jpeg'
  },
  {
    id: '3',
    title: 'בניית תיק השקעות ראשון',
    category: 'השקעות',
    summary: 'מדריך בסיסי להבנת עולם ההשקעות והתחלת בניית תיק השקעות בגיל צעיר.',
    readTime: 15,
    author: 'מיכל ברק',
    tags: ['השקעות', 'חיסכון', 'כסף'],
    image: 'https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg'
  },
  {
    id: '4',
    title: 'איך לכתוב קורות חיים מנצחים',
    category: 'קריירה',
    summary: 'המדריך המלא ליצירת קורות חיים שיבלטו ויעזרו לכם להשיג את העבודה הרצויה.',
    readTime: 10,
    author: 'יעל אברהם',
    tags: ['קורות חיים', 'עבודה', 'קריירה'],
    image: 'https://images.pexels.com/photos/4240505/pexels-photo-4240505.jpeg'
  },
  {
    id: '5',
    title: 'ניהול זמן אפקטיבי',
    category: 'פיתוח אישי',
    summary: 'טכניקות וכלים לניהול זמן יעיל, שילוב בין לימודים, עבודה ופנאי.',
    readTime: 7,
    author: 'אורי שביט',
    tags: ['ניהול זמן', 'פרודוקטיביות', 'איזון'],
    image: 'https://images.pexels.com/photos/1438081/pexels-photo-1438081.jpeg'
  },
  {
    id: '6',
    title: 'חיסכון לטווח ארוך',
    category: 'ניהול כספים',
    summary: 'אסטרטגיות לבניית תוכנית חיסכון ארוכת טווח והשגת יעדים פיננסיים.',
    readTime: 10,
    author: 'טל גולן',
    tags: ['חיסכון', 'תכנון פיננסי', 'יעדים'],
    image: 'https://images.pexels.com/photos/4386339/pexels-photo-4386339.jpeg'
  }
];

const categories = [
  'הכל',
  'ניהול כספים',
  'קריירה',
  'השקעות',
  'פיתוח אישי'
];

const GuidesPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('הכל');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredGuides = guides.filter(guide => {
    const matchesCategory = selectedCategory === 'הכל' || guide.category === selectedCategory;
    const matchesSearch = guide.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         guide.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         guide.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="pb-2">
        <h1 className="text-2xl md:text-3xl font-bold text-gray-800 flex items-center">
          <BookOpen className="mr-2 h-8 w-8 text-primary-500" />
          מדריכים וטיפים
        </h1>
        <p className="text-gray-600 mt-1">
          מדריכים מקצועיים לניהול כספים, קריירה ופיתוח אישי
        </p>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="חפש מדריכים..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Guides Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredGuides.map((guide) => (
          <Card
            key={guide.id}
            variant="hover"
            className="overflow-hidden flex flex-col"
          >
            <img
              src={guide.image}
              alt={guide.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6 flex-1 flex flex-col">
              <div className="flex-1">
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                  {guide.category}
                </span>
                <h3 className="mt-2 text-xl font-semibold text-gray-900">
                  {guide.title}
                </h3>
                <p className="mt-2 text-gray-600 text-sm">
                  {guide.summary}
                </p>
              </div>
              
              <div className="mt-4 space-y-3">
                <div className="flex flex-wrap gap-2">
                  {guide.tags.map((tag) => (
                    <span
                      key={tag}
                      className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800"
                    >
                      <Tag size={12} className="ml-1" />
                      {tag}
                    </span>
                  ))}
                </div>
                
                <div className="flex items-center justify-between pt-2 border-t">
                  <div className="flex items-center text-sm text-gray-500">
                    <User size={16} className="ml-1" />
                    {guide.author}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock size={16} className="ml-1" />
                    {guide.readTime} דקות קריאה
                  </div>
                </div>
                
                <Link to={`/guides/${guide.id}`}>
                  <Button
                    variant="outline"
                    fullWidth
                    className="mt-2"
                    icon={<ArrowRight size={16} />}
                  >
                    קרא עוד
                  </Button>
                </Link>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default GuidesPage;