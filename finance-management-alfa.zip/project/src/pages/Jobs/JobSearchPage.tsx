import React, { useState } from 'react';
import { useJob } from '../../context/JobContext';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { 
  Search, 
  MapPin, 
  DollarSign, 
  Briefcase, 
  Calendar, 
  Bookmark,
  Send,
  Globe
} from 'lucide-react';
import { Job } from '../../types';

const JobSearchPage: React.FC = () => {
  const { searchResults, searchJobs, saveJob, applyForJob, savedJobs } = useJob();
  
  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    type: [] as Array<'permanent' | 'temporary' | 'project'>,
    location: '',
    remote: null as boolean | null,
    minSalary: '',
  });

  // Handle job save/application
  const handleSaveJob = (job: Job) => {
    saveJob(job);
  };

  const handleApplyForJob = (job: Job) => {
    applyForJob(job);
  };

  const isJobSaved = (jobId: string) => {
    return savedJobs.some(saved => saved.job.id === jobId);
  };

  // Handle search and filters
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    searchJobs(searchQuery, filters);
  };

  const handleFilterChange = (
    name: string, 
    value: string | boolean | Array<'permanent' | 'temporary' | 'project'>
  ) => {
    setFilters({ ...filters, [name]: value });
  };

  return (
    <div className="space-y-6">
      <div className="pb-2">
        <h1 className="text-2xl md:text-3xl font-bold text-gray-800 flex items-center">
          <Briefcase className="mr-2 h-8 w-8 text-secondary-500" />
          חיפוש עבודות
        </h1>
        <p className="text-gray-600 mt-1">
          מצא את העבודה המושלמת לגיל ולכישורים שלך
        </p>
      </div>
      
      {/* Search Section */}
      <Card className="animate-fade-in">
        <form onSubmit={handleSearch} className="space-y-4">
          <div className="relative">
            <Search className="h-5 w-5 absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="חפש לפי תפקיד, חברה, מיקום..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="block w-full pr-10 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 text-md"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Job Types */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">סוג עבודה</label>
              <div className="flex space-x-4 space-x-reverse">
                <label className="inline-flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.type.includes('permanent')}
                    onChange={(e) => {
                      const newTypes = [...filters.type];
                      if (e.target.checked) {
                        newTypes.push('permanent');
                      } else {
                        const index = newTypes.indexOf('permanent');
                        if (index > -1) {
                          newTypes.splice(index, 1);
                        }
                      }
                      handleFilterChange('type', newTypes);
                    }}
                    className="form-checkbox h-4 w-4 text-secondary-600"
                  />
                  <span className="mr-2 text-sm text-gray-700">קבוע</span>
                </label>
                <label className="inline-flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.type.includes('temporary')}
                    onChange={(e) => {
                      const newTypes = [...filters.type];
                      if (e.target.checked) {
                        newTypes.push('temporary');
                      } else {
                        const index = newTypes.indexOf('temporary');
                        if (index > -1) {
                          newTypes.splice(index, 1);
                        }
                      }
                      handleFilterChange('type', newTypes);
                    }}
                    className="form-checkbox h-4 w-4 text-secondary-600"
                  />
                  <span className="mr-2 text-sm text-gray-700">זמני</span>
                </label>
                <label className="inline-flex items-center">
                  <input
                    type="checkbox"
                    checked={filters.type.includes('project')}
                    onChange={(e) => {
                      const newTypes = [...filters.type];
                      if (e.target.checked) {
                        newTypes.push('project');
                      } else {
                        const index = newTypes.indexOf('project');
                        if (index > -1) {
                          newTypes.splice(index, 1);
                        }
                      }
                      handleFilterChange('type', newTypes);
                    }}
                    className="form-checkbox h-4 w-4 text-secondary-600"
                  />
                  <span className="mr-2 text-sm text-gray-700">פרויקט</span>
                </label>
              </div>
            </div>
            
            {/* Location */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">מיקום</label>
              <input
                type="text"
                placeholder="עיר או אזור"
                value={filters.location}
                onChange={(e) => handleFilterChange('location', e.target.value)}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-secondary-500 focus:border-secondary-500 text-sm"
              />
            </div>
            
            {/* Remote Option */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">עבודה מרחוק</label>
              <select
                value={filters.remote === null ? '' : String(filters.remote)}
                onChange={(e) => {
                  const value = e.target.value;
                  handleFilterChange('remote', value === '' ? null : value === 'true');
                }}
                className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-secondary-500 focus:border-secondary-500 text-sm"
              >
                <option value="">הכל</option>
                <option value="true">עבודה מרחוק</option>
                <option value="false">עבודה במשרד/בשטח</option>
              </select>
            </div>
          </div>
          
          <div className="flex justify-between">
            <Button 
              type="button" 
              variant="outline"
              onClick={() => {
                setSearchQuery('');
                setFilters({
                  type: [],
                  location: '',
                  remote: null,
                  minSalary: '',
                });
              }}
            >
              נקה הכל
            </Button>
            <Button type="submit" variant="primary" icon={<Search size={16} />}>
              חפש
            </Button>
          </div>
        </form>
      </Card>
      
      {/* Results Section */}
      <div className="mt-6">
        <h2 className="text-xl font-semibold mb-4">תוצאות חיפוש</h2>
        
        <div className="space-y-4">
          {searchResults.length === 0 ? (
            <Card>
              <div className="text-center py-8">
                <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-gray-100 mb-4">
                  <Briefcase className="h-6 w-6 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">לא נמצאו משרות</h3>
                <p className="mt-2 text-sm text-gray-500">
                  נסה לשנות את מונחי החיפוש או למחוק מסננים
                </p>
              </div>
            </Card>
          ) : (
            searchResults.map((job) => (
              <Card key={job.id} variant="hover" className="overflow-hidden">
                <div className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900">{job.title}</h3>
                      <p className="text-sm text-gray-600 mt-1">{job.company}</p>
                    </div>
                    
                    <div className="flex space-x-2 space-x-reverse">
                      <Button
                        variant={isJobSaved(job.id) ? 'secondary' : 'outline'}
                        size="sm"
                        icon={<Bookmark size={16} />}
                        onClick={() => handleSaveJob(job)}
                      >
                        {isJobSaved(job.id) ? 'נשמר' : 'שמור'}
                      </Button>
                      <Button
                        variant="primary"
                        size="sm"
                        icon={<Send size={16} />}
                        onClick={() => handleApplyForJob(job)}
                      >
                        הגש מועמדות
                      </Button>
                    </div>
                  </div>
                  
                  <div className="mt-4 grid grid-cols-2 gap-4">
                    <div className="col-span-2 md:col-span-1">
                      <div className="flex items-start">
                        <div className="flex-shrink-0 mt-0.5">
                          <DollarSign className="h-5 w-5 text-gray-400" />
                        </div>
                        <div className="mr-2">
                          <dt className="text-sm font-medium text-gray-500">שכר</dt>
                          <dd className="text-sm text-gray-900">
                            {job.salary.amount} ₪
                            {job.salary.period && ` ${
                              {
                                'hour': 'לשעה',
                                'day': 'ליום',
                                'week': 'לשבוע',
                                'month': 'לחודש',
                                'project': 'לפרויקט',
                              }[job.salary.period]
                            }`}
                          </dd>
                        </div>
                      </div>
                    </div>
                    
                    <div className="col-span-2 md:col-span-1">
                      <div className="flex items-start">
                        <div className="flex-shrink-0 mt-0.5">
                          <Briefcase className="h-5 w-5 text-gray-400" />
                        </div>
                        <div className="mr-2">
                          <dt className="text-sm font-medium text-gray-500">סוג משרה</dt>
                          <dd className="text-sm text-gray-900">
                            {{
                              permanent: 'קבוע',
                              temporary: 'זמני',
                              project: 'פרויקט',
                            }[job.type]}
                          </dd>
                        </div>
                      </div>
                    </div>
                    
                    <div className="col-span-2 md:col-span-1">
                      <div className="flex items-start">
                        <div className="flex-shrink-0 mt-0.5">
                          <MapPin className="h-5 w-5 text-gray-400" />
                        </div>
                        <div className="mr-2">
                          <dt className="text-sm font-medium text-gray-500">מיקום</dt>
                          <dd className="text-sm text-gray-900">{job.location}</dd>
                        </div>
                      </div>
                    </div>
                    
                    <div className="col-span-2 md:col-span-1">
                      <div className="flex items-start">
                        <div className="flex-shrink-0 mt-0.5">
                          {job.remote ? (
                            <Globe className="h-5 w-5 text-gray-400" />
                          ) : (
                            <MapPin className="h-5 w-5 text-gray-400" />
                          )}
                        </div>
                        <div className="mr-2">
                          <dt className="text-sm font-medium text-gray-500">עבודה מרחוק</dt>
                          <dd className="text-sm text-gray-900">
                            {job.remote ? 'כן' : 'לא'}
                          </dd>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-4">
                    <div className="flex items-start">
                      <p className="text-sm text-gray-500 mt-1">{job.description}</p>
                    </div>
                  </div>
                  
                  {job.requirements && job.requirements.length > 0 && (
                    <div className="mt-4">
                      <h4 className="text-sm font-medium text-gray-700">דרישות:</h4>
                      <ul className="mt-1 list-disc list-inside text-sm text-gray-500">
                        {job.requirements.map((req, index) => (
                          <li key={index}>{req}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  <div className="mt-3 text-right">
                    <div className="flex items-center justify-end text-sm text-gray-500">
                      <Calendar size={14} className="ml-1" />
                      פורסם ב-{new Date(job.postedDate).toLocaleDateString('he-IL')}
                    </div>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default JobSearchPage;